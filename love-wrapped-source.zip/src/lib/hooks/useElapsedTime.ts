"use client";

import { useEffect, useState } from "react";

export function useElapsedTime(startTime?: number) {
  const [elapsed, setElapsed] = useState(0);

  useEffect(() => {
    const start = startTime ?? Date.now();

    const interval = setInterval(() => {
      setElapsed(Date.now() - start);
    }, 1000);

    return () => clearInterval(interval);
  }, [startTime]);

  return elapsed;
}